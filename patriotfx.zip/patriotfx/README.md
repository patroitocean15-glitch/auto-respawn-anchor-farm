# PatriotFX (Meteor Client Addon)

Baritone'suz Respawn Anchor Farm.

## Build
Gradle wrapper jar'ı dahil değil; resmi şablondan `gradle/wrapper` klasörünü kopyala (ya da sistemde gradle kullan):
    ./gradlew build
Çıktı: build/libs/patriotfx-*.jar  -> .minecraft/mods (Meteor Client ile birlikte)

## Modül: respawn-anchor-farm (kategori: PatriotFX)
- chunk-radius (16) içinde yüklü chunklarda Respawn Anchor arar
- Bulursa yürür, kırar, drop'u toplar
- Bulamazsa rtp-command (/rtp) yazar; region menüsü açılırsa region-slot'a tıklar
- Önüne blok çıkıp takılırsa ender pearl atar ve yola devam eder
- Player ESP (kutu + tracer) içinde; oyuncu görürse panic -> RTP
