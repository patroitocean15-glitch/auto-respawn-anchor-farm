package com.patriotfx.addon.modules;

import com.patriotfx.addon.PatriotFX;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

/**
 * PatriotFX - Respawn Anchor Farm
 * Baritone KULLANMAZ. Kendi yürüme / engel aşma / ender pearl mantığı vardır.
 * Player ESP + Panic modülün içine gömülüdür.
 */
public class RespawnAnchorFarm extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgObstacle = settings.createGroup("Obstacle / Pearl");
    private final SettingGroup sgRtp = settings.createGroup("RTP");
    private final SettingGroup sgEsp = settings.createGroup("Player ESP / Panic");
    private final SettingGroup sgRender = settings.createGroup("Render");

    // ---------------- General ----------------
    private final Setting<Integer> chunkRadius = sgGeneral.add(new IntSetting.Builder()
        .name("chunk-radius").description("Anchor aramak için taranacak chunk yarıçapı (yüklü chunklar).")
        .defaultValue(16).range(1, 32).sliderRange(1, 32).build());

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval").description("Kaç tickte bir tarama yapılsın.")
        .defaultValue(10).range(1, 100).sliderRange(1, 40).build());

    private final Setting<Double> reach = sgGeneral.add(new DoubleSetting.Builder()
        .name("reach").description("Anchor'ı kırmaya başlama mesafesi.")
        .defaultValue(4.4).range(2, 5.5).sliderRange(2, 5.5).build());

    private final Setting<Boolean> sprint = sgGeneral.add(new BoolSetting.Builder()
        .name("sprint").description("Koşarak git.").defaultValue(true).build());

    private final Setting<Integer> collectTicks = sgGeneral.add(new IntSetting.Builder()
        .name("collect-ticks").description("Kırdıktan sonra drop'u toplamak için bekleme süresi.")
        .defaultValue(25).range(0, 100).sliderRange(0, 60).build());

    private final Setting<Integer> giveUpTicks = sgGeneral.add(new IntSetting.Builder()
        .name("give-up-ticks").description("Bir anchor'a bu kadar tickte ulaşılamazsa blacklist'e alınır.")
        .defaultValue(600).range(100, 3000).sliderRange(100, 1500).build());

    // ---------------- Obstacle ----------------
    private final Setting<Boolean> usePearl = sgObstacle.add(new BoolSetting.Builder()
        .name("pearl-on-obstacle").description("Önüne taş/blok çıkıp takılırsa ender pearl atıp kurtul.")
        .defaultValue(true).build());

    private final Setting<Integer> stuckTicks = sgObstacle.add(new IntSetting.Builder()
        .name("stuck-ticks").description("Bu kadar tick hareket edemezse takıldı sayılır.")
        .defaultValue(14).range(5, 80).sliderRange(5, 40).build());

    private final Setting<Integer> pearlCooldown = sgObstacle.add(new IntSetting.Builder()
        .name("pearl-cooldown").description("İki pearl arası minimum tick.")
        .defaultValue(40).range(10, 200).sliderRange(10, 100).build());

    private final Setting<Double> pearlDistance = sgObstacle.add(new DoubleSetting.Builder()
        .name("pearl-distance").description("Pearl'ün hedefe doğru yaklaşık kaç blok ileri düşmesi istenir.")
        .defaultValue(14).range(6, 40).sliderRange(6, 40).build());

    // ---------------- RTP ----------------
    private final Setting<String> rtpCommand = sgRtp.add(new StringSetting.Builder()
        .name("rtp-command").description("Anchor bulunamayınca yazılacak komut.")
        .defaultValue("/rtp").build());

    private final Setting<Integer> rtpCooldown = sgRtp.add(new IntSetting.Builder()
        .name("rtp-cooldown").description("İki RTP arası minimum tick (sunucu cooldown'una göre ayarla).")
        .defaultValue(100).range(20, 1200).sliderRange(20, 600).build());

    private final Setting<Integer> regionSlot = sgRtp.add(new IntSetting.Builder()
        .name("region-slot").description("/rtp bir region menüsü açıyorsa tıklanacak slot. -1 = kapalı.")
        .defaultValue(-1).range(-1, 53).sliderRange(-1, 53).build());

    private final Setting<Integer> regionClickDelay = sgRtp.add(new IntSetting.Builder()
        .name("region-click-delay").description("Menü açıldıktan kaç tick sonra tıklansın.")
        .defaultValue(8).range(0, 40).sliderRange(0, 40).build());

    private final Setting<Integer> minTeleportDistance = sgRtp.add(new IntSetting.Builder()
        .name("min-teleport-distance").description("Bu mesafeden fazla yer değiştirirsek RTP başarılı sayılır.")
        .defaultValue(40).range(5, 500).sliderRange(5, 200).build());

    private final Setting<Integer> rtpTimeout = sgRtp.add(new IntSetting.Builder()
        .name("rtp-timeout").description("RTP bu kadar tick içinde gerçekleşmezse tekrar taranır.")
        .defaultValue(300).range(40, 1200).sliderRange(40, 600).build());

    private final Setting<Integer> postRtpDelay = sgRtp.add(new IntSetting.Builder()
        .name("post-rtp-delay").description("Işınlandıktan sonra chunkların yüklenmesi için bekleme.")
        .defaultValue(60).range(0, 400).sliderRange(0, 200).build());

    // ---------------- Player ESP / Panic ----------------
    private final Setting<Boolean> playerEsp = sgEsp.add(new BoolSetting.Builder()
        .name("player-esp").description("Oyuncuları kutu içine al.").defaultValue(true).build());

    private final Setting<Boolean> tracers = sgEsp.add(new BoolSetting.Builder()
        .name("tracers").description("Oyunculara çizgi çiz.").defaultValue(true).build());

    private final Setting<Boolean> panic = sgEsp.add(new BoolSetting.Builder()
        .name("panic").description("Oyuncu görürsen panic yapıp RTP at.").defaultValue(true).build());

    private final Setting<Double> panicDistance = sgEsp.add(new DoubleSetting.Builder()
        .name("panic-distance").description("Bu mesafedeki oyuncu panic tetikler.")
        .defaultValue(128).range(8, 512).sliderRange(8, 256).build());

    private final Setting<Boolean> ignoreFriends = sgEsp.add(new BoolSetting.Builder()
        .name("ignore-friends").description("Arkadaşları yok say.").defaultValue(true).build());

    private final Setting<SettingColor> espColor = sgEsp.add(new ColorSetting.Builder()
        .name("esp-color").description("Oyuncu ESP rengi.")
        .defaultValue(new SettingColor(255, 40, 80, 255)).build());

    // ---------------- Render ----------------
    private final Setting<Boolean> renderTarget = sgRender.add(new BoolSetting.Builder()
        .name("render-target").description("Hedef anchor'ı göster.").defaultValue(true).build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").defaultValue(ShapeMode.Both).build());

    private final Setting<SettingColor> targetSide = sgRender.add(new ColorSetting.Builder()
        .name("target-side-color").defaultValue(new SettingColor(120, 40, 255, 40)).build());

    private final Setting<SettingColor> targetLine = sgRender.add(new ColorSetting.Builder()
        .name("target-line-color").defaultValue(new SettingColor(160, 80, 255, 255)).build());

    // ---------------- State ----------------
    private enum State { SCANNING, WALKING, MINING, COLLECTING, RTP_WAIT, SETTLE }

    private State state = State.SCANNING;
    private BlockPos target;
    private final Set<BlockPos> blacklist = new HashSet<>();

    private int scanTimer, rtpTimer, stateTimer, stuckCounter, pearlTimer, pearlGrace, settleTimer;
    private int menuTimer;
    private boolean awaitingRegion;
    private Vec3 lastPos, rtpStartPos;
    private String threatName;

    public RespawnAnchorFarm() {
        super(PatriotFX.CATEGORY, "respawn-anchor-farm",
            "Yakındaki Respawn Anchor'ları bulup kırar. Yoksa /rtp atar. Player ESP + panic içinde. (Baritone yok)");
    }

    @Override
    public void onActivate() {
        reset();
    }

    @Override
    public void onDeactivate() {
        releaseKeys();
        reset();
    }

    private void reset() {
        state = State.SCANNING;
        target = null;
        scanTimer = rtpTimer = stateTimer = stuckCounter = pearlTimer = pearlGrace = settleTimer = menuTimer = 0;
        awaitingRegion = false;
        lastPos = null;
        rtpStartPos = null;
        threatName = null;
    }

    @Override
    public String getInfoString() {
        return state.name();
    }

    // =====================================================================
    //  TICK
    // =====================================================================
    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.level == null) return;

        if (rtpTimer > 0) rtpTimer--;
        if (pearlTimer > 0) pearlTimer--;
        if (pearlGrace > 0) pearlGrace--;

        handleRegionMenu();

        // Player ESP -> Panic
        threatName = null;
        Player threat = findThreat();
        if (threat != null) {
            threatName = threat.getName().getString();
            if (panic.get() && state != State.RTP_WAIT && state != State.SETTLE && rtpTimer == 0) {
                info("PANIC! " + threatName + " goruldu, RTP atiliyor.");
                releaseKeys();
                target = null;
                doRtp();
                return;
            }
        }

        switch (state) {
            case SCANNING -> tickScanning();
            case WALKING -> tickWalking();
            case MINING -> tickMining();
            case COLLECTING -> tickCollecting();
            case RTP_WAIT -> tickRtpWait();
            case SETTLE -> {
                if (--settleTimer <= 0) state = State.SCANNING;
            }
        }
    }

    // ---------------- SCANNING ----------------
    private void tickScanning() {
        releaseKeys();
        if (--scanTimer > 0) return;
        scanTimer = scanInterval.get();

        BlockPos found = findNearestAnchor();
        if (found != null) {
            target = found;
            state = State.WALKING;
            stateTimer = 0;
            stuckCounter = 0;
            lastPos = mc.player.position();
            info("Respawn Anchor bulundu: %d %d %d", found.getX(), found.getY(), found.getZ());
        } else {
            doRtp();
        }
    }

    // ---------------- WALKING ----------------
    private void tickWalking() {
        if (!isAnchor(target)) {
            target = null;
            state = State.SCANNING;
            return;
        }

        Vec3 center = Vec3.atCenterOf(target);
        if (mc.player.getEyePosition().distanceTo(center) <= reach.get()) {
            releaseKeys();
            state = State.MINING;
            stateTimer = 0;
            return;
        }

        if (++stateTimer > giveUpTicks.get()) {
            warning("Anchor'a ulasilamadi, blacklist'e alindi.");
            blacklist(target);
            return;
        }

        walkTowards(center);

        // Takılma tespiti
        Vec3 now = mc.player.position();
        double moved = lastPos == null ? 1 : Math.hypot(now.x - lastPos.x, now.z - lastPos.z);
        lastPos = now;

        if (pearlGrace > 0) {
            stuckCounter = 0;
        } else if (moved < 0.03) {
            stuckCounter++;
        } else {
            stuckCounter = 0;
        }

        if (stuckCounter >= stuckTicks.get()) {
            stuckCounter = 0;
            if (usePearl.get() && pearlTimer == 0 && throwPearl(center)) {
                // başarılı
            } else if (!usePearl.get() || !InvUtils.findInHotbar(Items.ENDER_PEARL).found()) {
                // pearl yok: sağa/sola sapmayı dene, uzun süre takılırsa vazgeç
                stateTimer += 40;
            }
        }
    }

    private void walkTowards(Vec3 pos) {
        float yaw = (float) Rotations.getYaw(pos);
        mc.player.setYRot(yaw);
        mc.player.setXRot(10);

        mc.options.keyUp.setDown(true);
        mc.options.keySprint.setDown(sprint.get());

        boolean jump = mc.player.horizontalCollision || mc.player.isInWater() || mc.player.isInLava();
        mc.options.keyJump.setDown(jump);
    }

    // ---------------- Pearl ----------------
    private boolean throwPearl(Vec3 targetPos) {
        FindItemResult pearl = InvUtils.findInHotbar(Items.ENDER_PEARL);
        if (!pearl.found()) return false;

        double dx = targetPos.x - mc.player.getX();
        double dz = targetPos.z - mc.player.getZ();
        double hDist = Math.hypot(dx, dz);
        double desired = Mth.clamp(hDist, 6, pearlDistance.get());

        float yaw = (float) Rotations.getYaw(targetPos);
        float pitch = bestPearlPitch(desired);

        releaseKeys();
        Rotations.rotate(yaw, pitch, 100, () -> {
            if (!InvUtils.swap(pearl.slot(), true)) return;
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            InvUtils.swapBack();
        });

        pearlTimer = pearlCooldown.get();
        pearlGrace = 40;
        info("Engel! Ender pearl atildi.");
        return true;
    }

    /** Pearl'ün istenen yatay mesafeye düşeceği en yüksek açılı (engel aşan) pitch'i bulur. */
    private float bestPearlPitch(double desired) {
        float best = -45;
        double bestDiff = Double.MAX_VALUE;
        for (int p = -70; p <= -10; p++) {
            double range = simulatePearlRange(p);
            double diff = Math.abs(range - desired);
            if (diff < bestDiff) { // eşitlikte ilk (daha dik) kalır
                bestDiff = diff;
                best = p;
            }
        }
        return best;
    }

    private double simulatePearlRange(float pitchDeg) {
        double rad = Math.toRadians(pitchDeg);
        double vh = Math.cos(rad) * 1.5;
        double vy = -Math.sin(rad) * 1.5;
        double h = 0, y = 0;
        for (int i = 0; i < 200; i++) {
            h += vh;
            y += vy;
            vh *= 0.99;
            vy = vy * 0.99 - 0.03;
            if (y < 0 && vy < 0) break;
        }
        return h;
    }

    // ---------------- MINING ----------------
    private void tickMining() {
        if (!isAnchor(target)) {
            // kırıldı
            state = State.COLLECTING;
            stateTimer = collectTicks.get();
            return;
        }

        Vec3 center = Vec3.atCenterOf(target);
        if (mc.player.getEyePosition().distanceTo(center) > reach.get() + 1.0) {
            state = State.WALKING;
            return;
        }

        if (++stateTimer > 400) {
            warning("Anchor kirilamadi, blacklist'e alindi.");
            blacklist(target);
            return;
        }

        BlockState bs = mc.level.getBlockState(target);
        FindItemResult tool = InvUtils.findFastestTool(bs);
        if (tool.found()) InvUtils.swap(tool.slot(), false);

        BlockPos pos = target;
        Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), 50, () -> BlockUtils.breakBlock(pos, true));
    }

    // ---------------- COLLECTING ----------------
    private void tickCollecting() {
        if (target != null && stateTimer > 0) {
            Vec3 c = Vec3.atBottomCenterOf(target);
            double d = Math.hypot(c.x - mc.player.getX(), c.z - mc.player.getZ());
            if (d > 0.7) walkTowards(c);
            else releaseKeys();
            stateTimer--;
        } else {
            releaseKeys();
            target = null;
            state = State.SCANNING;
            scanTimer = 0;
        }
    }

    // ---------------- RTP ----------------
    private void doRtp() {
        if (rtpTimer > 0) {
            // cooldown beklerken taramaya devam et
            if (state != State.SCANNING) state = State.SCANNING;
            return;
        }
        releaseKeys();
        info("Anchor yok -> %s", rtpCommand.get());
        ChatUtils.sendPlayerMsg(rtpCommand.get());
        rtpTimer = rtpCooldown.get();
        rtpStartPos = mc.player.position();
        stateTimer = 0;
        menuTimer = 0;
        awaitingRegion = regionSlot.get() >= 0;
        state = State.RTP_WAIT;
    }

    private void tickRtpWait() {
        releaseKeys();
        stateTimer++;

        boolean teleported = rtpStartPos != null && mc.player.position().distanceTo(rtpStartPos) >= minTeleportDistance.get();
        if (teleported) {
            awaitingRegion = false;
            state = State.SETTLE;
            settleTimer = postRtpDelay.get();
            blacklist.clear();
            return;
        }

        if (stateTimer > rtpTimeout.get()) {
            awaitingRegion = false;
            state = State.SCANNING;
            scanTimer = 0;
        }
    }

    private void handleRegionMenu() {
        if (!awaitingRegion) return;
        if (!(mc.screen instanceof AbstractContainerScreen<?> screen)) return;

        if (++menuTimer >= regionClickDelay.get()) {
            mc.gameMode.handleContainerInput(screen.getMenu().containerId, regionSlot.get(), 0, ContainerInput.PICKUP, mc.player);
            awaitingRegion = false;
            menuTimer = 0;
        }
    }

    // =====================================================================
    //  SCAN
    // =====================================================================
    private boolean isAnchor(BlockPos pos) {
        return pos != null && mc.level.getBlockState(pos).is(Blocks.RESPAWN_ANCHOR);
    }

    private void blacklist(BlockPos pos) {
        if (pos != null) blacklist.add(pos.immutable());
        target = null;
        releaseKeys();
        state = State.SCANNING;
        scanTimer = 0;
    }

    private BlockPos findNearestAnchor() {
        int pcx = mc.player.blockPosition().getX() >> 4;
        int pcz = mc.player.blockPosition().getZ() >> 4;
        int r = chunkRadius.get();

        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        Vec3 pp = mc.player.position();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();

        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                ChunkAccess chunk = mc.level.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;

                LevelChunkSection[] sections = chunk.getSections();
                for (int i = 0; i < sections.length; i++) {
                    LevelChunkSection section = sections[i];
                    if (section == null || section.hasOnlyAir()) continue;
                    if (!section.maybeHas(s -> s.is(Blocks.RESPAWN_ANCHOR))) continue;

                    int baseY = chunk.getMinY() + i * 16;
                    for (int x = 0; x < 16; x++) {
                        for (int y = 0; y < 16; y++) {
                            for (int z = 0; z < 16; z++) {
                                if (!section.getBlockState(x, y, z).is(Blocks.RESPAWN_ANCHOR)) continue;
                                mp.set((cx << 4) + x, baseY + y, (cz << 4) + z);
                                if (blacklist.contains(mp)) continue;

                                double d = pp.distanceToSqr(mp.getX() + 0.5, mp.getY() + 0.5, mp.getZ() + 0.5);
                                if (d < bestDist) {
                                    bestDist = d;
                                    best = mp.immutable();
                                }
                            }
                        }
                    }
                }
            }
        }
        return best;
    }

    // =====================================================================
    //  PLAYER ESP / PANIC
    // =====================================================================
    private Player findThreat() {
        Player nearest = null;
        double nd = Double.MAX_VALUE;
        double max = panicDistance.get();

        for (Player p : mc.level.players()) {
            if (p == mc.player || p.isSpectator() || !p.isAlive()) continue;
            if (ignoreFriends.get() && Friends.get().isFriend(p)) continue;
            double d = mc.player.distanceTo(p);
            if (d <= max && d < nd) {
                nd = d;
                nearest = p;
            }
        }
        return nearest;
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.player == null || mc.level == null) return;

        if (playerEsp.get()) {
            SettingColor c = espColor.get();
            SettingColor side = new SettingColor(c.r, c.g, c.b, 40);
            for (Player p : mc.level.players()) {
                if (p == mc.player || p.isSpectator()) continue;
                if (ignoreFriends.get() && Friends.get().isFriend(p)) continue;

                double x = Mth.lerp(event.tickDelta, p.xOld, p.getX()) - p.getX();
                double y = Mth.lerp(event.tickDelta, p.yOld, p.getY()) - p.getY();
                double z = Mth.lerp(event.tickDelta, p.zOld, p.getZ()) - p.getZ();
                AABB b = p.getBoundingBox();

                event.renderer.box(b.minX + x, b.minY + y, b.minZ + z, b.maxX + x, b.maxY + y, b.maxZ + z,
                    side, c, ShapeMode.Both, 0);

                if (tracers.get()) {
                    event.renderer.line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z,
                        p.getX() + x, p.getY() + y + p.getBbHeight() / 2, p.getZ() + z, c);
                }
            }
        }

        if (renderTarget.get() && target != null && isAnchor(target)) {
            event.renderer.box(target, targetSide.get(), targetLine.get(), shapeMode.get(), 0);
            event.renderer.line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z,
                target.getX() + 0.5, target.getY() + 0.5, target.getZ() + 0.5, targetLine.get());
        }
    }

    // =====================================================================
    private void releaseKeys() {
        if (mc.options == null) return;
        mc.options.keyUp.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keySprint.setDown(false);
    }
}
