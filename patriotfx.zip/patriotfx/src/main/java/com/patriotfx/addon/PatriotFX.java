package com.patriotfx.addon;

import com.mojang.logging.LogUtils;
import com.patriotfx.addon.modules.RespawnAnchorFarm;
import meteordevelopment.meteorclient.addons.GithubRepo;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;

public class PatriotFX extends MeteorAddon {
    public static final Logger LOG = LogUtils.getLogger();
    public static final Category CATEGORY = new Category("PatriotFX");

    @Override
    public void onInitialize() {
        LOG.info("Initializing PatriotFX");
        Modules.get().add(new RespawnAnchorFarm());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.patriotfx.addon";
    }

    @Override
    public GithubRepo getRepo() {
        return new GithubRepo("PatriotFX", "patriotfx");
    }
}
